<?php
/**
 * @package     Sobi\Lib
 * @subpackage
 *
 * @copyright   A copyright
 * @license     A "Slug" license name e.g. GPL2
 */

namespace Sobi\Lib;


class Object
{

}
