<?php
function civicrmVersion( ) {
  return array( 'version'  => '4.6.33',
                'cms'      => 'Joomla',
                'revision' => '' );
}

