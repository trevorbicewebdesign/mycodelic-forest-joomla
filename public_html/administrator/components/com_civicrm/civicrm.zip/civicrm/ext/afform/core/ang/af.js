(function(angular, $, _) {
  // Declare a list of dependencies.
  angular.module('af', CRM.angRequires('af'));
})(angular, CRM.$, CRM._);
