<?php
return [
  'js' => [
    'ang/unvalidatedJwtDecode.js',
  ],
  'requires' => [
    'crmUi',
    'crmUtil',
  ],
];
