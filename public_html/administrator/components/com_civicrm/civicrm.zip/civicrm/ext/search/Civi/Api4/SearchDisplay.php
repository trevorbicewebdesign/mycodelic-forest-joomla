<?php
namespace Civi\Api4;

/**
 * SearchDisplay entity.
 *
 * Provided by the Search Kit extension.
 *
 * @searchable false
 * @package Civi\Api4
 */
class SearchDisplay extends Generic\DAOEntity {

}
