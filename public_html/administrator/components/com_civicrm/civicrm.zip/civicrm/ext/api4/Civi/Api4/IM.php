<?php

namespace Civi\Api4;

/**
 * IM entity.
 *
 * @package Civi\Api4
 */
class IM extends Generic\DAOEntity {

}
