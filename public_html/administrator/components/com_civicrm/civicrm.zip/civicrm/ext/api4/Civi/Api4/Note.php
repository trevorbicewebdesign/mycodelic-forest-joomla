<?php

namespace Civi\Api4;

/**
 * Note entity.
 *
 * @package Civi\Api4
 */
class Note extends Generic\DAOEntity {

}
