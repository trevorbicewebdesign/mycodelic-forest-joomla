<?php

namespace Civi\Api4;

/**
 * Event entity.
 *
 * @package Civi\Api4
 */
class Event extends Generic\DAOEntity {

}
