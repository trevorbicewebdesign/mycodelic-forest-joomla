***************
** JS Folder **
***************

Here are some Javascript libraries used on the code or samples.

- swfobject.js

  SWFObject v2.2 <http://code.google.com/p/swfobject/> 
  is released under the MIT License <http://www.opensource.org/licenses/mit-license.php> 
